from flask import Flask, request, redirect, url_for, render_template
import os
print(os.getcwd())  # Prints the current working directory
print(os.listdir('./templates'))  # Lists all files in the templates folder

app = Flask(__name__)

@app.route('/')
def contact():
    return render_template('contact.html')

@app.route('/submit_form', methods=['POST'])
def submit_form():
    # Form data processing
    name = request.form['name']
    email = request.form['email']
    mobile = request.form['mobile']
    issue = request.form['issue']

    print(f"Name: {name}, Email: {email}, Mobile: {mobile}, Issue: {issue}")

    # Redirect to Thank You page
    return redirect(url_for('thank_you'))

@app.route('/thank_you')
def thank_you():
    return render_template('thankyou.html')

@app.route('/contact')
def work():
    return render_template('contact.html')

@app.route('/work')
def works():
    return render_template('work.html')

if __name__ == '__main__':
    app.run(debug=True)
